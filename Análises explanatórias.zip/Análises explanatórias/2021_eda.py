# -*- coding: utf-8 -*-
"""2021- EDA
Para esta análise, será utilizada a base de dados estruturados "Banco de Preço em Saúde - 2021", em formato .csv disponível em https://opendatasus.saude.gov.br/dataset/bps/resource/cbb99213-62b7-4d5c-ace2-c531fa9dc199.
"""

!java -version
!pip install --upgrade pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder \
  .appName("TesteSpark") \
  .getOrCreate()
print("Spark iniciado com sucesso!")

import pandas as pd
import numpy as np
import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

dados_2021 = spark.read.csv("/content/2021.csv", header=True, inferSchema=True)

#Formatação
dados_2021 = spark.read.option("header", True) \
             .option("sep", ";") \
             .option("encoding", "ISO-8859-1") \
             .option("quote", '"') \
             .option("escape", '"') \
             .csv("/content/2021.csv")

dados_2021.show(5, truncate=False)
dados_2021.printSchema()

#Criar as colunas "Capacidade", "Unidade_Medida" e "Unidade_Fornecimento_Capacidade"
spark = SparkSession.builder.getOrCreate()
from pyspark.sql import functions as F

dados_2021 = dados_2021.withColumn(
  "Capacidade", F.lit(None).cast("string")
).withColumn(
  "Unidade_Medida", F.lit(None).cast("string")
).withColumn(
  "Unidade_Fornecimento_Capacidade", F.lit(None).cast("string")
)
dados_2021.show(5, truncate=False)

spark = SparkSession.builder.getOrCreate()
#preencher células em branco
from pyspark.sql.functions import col, trim, when
dados_2021 = dados_2021.withColumn(
         "Anvisa",
          when(trim(col("Anvisa")) == "", None).otherwise(col("Anvisa"))
).withColumn("Anvisa", col("Anvisa").cast("string")) \
.fillna({"Anvisa": "Não consta"})

dados_2021 = dados_2021.withColumn(
         "Genérico",
          when(trim(col("Genérico")) == "", None).otherwise(col("Genérico"))
).withColumn("Genérico", col("Genérico").cast("string")) \
.fillna({"Genérico": "Não consta"})

dados_2021 = dados_2021.withColumn(
    "Capacidade",
    when(trim(col("Capacidade")) == "", None).otherwise(col("Capacidade"))
).fillna({"Capacidade": "Não consta"}) # Removed redundant .cast("string")
dados_2021.show(108, truncate=False)

dados_2021 = dados_2021.withColumn(
    "Unidade_Medida",
    when(trim(col("Unidade_Medida")) == "", None).otherwise(col("Unidade_Medida"))
).fillna({"Unidade_Medida": "Não consta"})

dados_2021 = dados_2021.withColumn(
    "Unidade_Fornecimento_Capacidade",
    when(trim(col("Unidade_Fornecimento_Capacidade")) == "", None).otherwise(col("Unidade_Fornecimento_Capacidade"))
).fillna({"Unidade_Fornecimento_Capacidade": "Não consta"})
dados_2021.show(108, truncate=False)

#Anonimizar CNPJ Fornecedor
from pyspark.sql.functions import col, regexp_replace
dados_2021 = dados_2021.withColumn(
          "CNPJ_Fornecedor",
          regexp_replace(col("CNPJ_Fornecedor"), r".*", "—")
)
dados_2021.show(5, truncate=False)

#Anonimizar CNPJ Fabricante
dados_2021 = dados_2021.withColumn(
          "CNPJ_Fabricante",
          regexp_replace(col("CNPJ_Fabricante"), r".*", "—")
)
dados_2021.show(5, truncate=False)

#Anonimizar CNPJ Instituição
dados_2021 = dados_2021.withColumn(
          "CNPJ_Instituição",
          regexp_replace(col("CNPJ_Instituição"), r".*", "—")
)
dados_2021.show(5, truncate=False)

#Total de operações
Total_operacoes = dados_2021.count()
print(f"Total de operações: {Total_operacoes}")

#Total de operações por estado
dados_2021.groupBy('UF').count().orderBy('count', ascending=False).show()

#Total de operações por fornecedor
dados_2021.groupBy('Fornecedor').count().orderBy('count', ascending=False).show()

#Total de operações por instituição
dados_2021.groupBy('Nome_Instituição').count().orderBy('count', ascending=False).show()

#Organizar os estados por região
from pyspark.sql import functions as F

dados_2021 = dados_2021.withColumn(
  "Região",
  F.when(F.col("UF").isin("SP", "RJ", "MG", "ES"), F.lit("Região sudeste"))
  .when(F.col("UF").isin("RS", "SC", "PR"), F.lit("Região sul"))
  .when(F.col("UF").isin("AC", "AP", "AM", "PA", "RO", "RR", "TO"), F.lit("Região norte"))
  .when(F.col("UF").isin("DF", "GO", "MT", "MS"), F.lit("Região centro-oeste"))
  .otherwise(F.lit("Região nordeste"))
)
dados_2021.show(5, truncate=False)

#Total de operações por região
dados_2021.groupBy('Região').count().orderBy('count', ascending=False).show()

#Cast regexp no preço
from pyspark.sql.functions import trim, when, regexp_replace, col, lit

preco_temp = trim(regexp_replace(regexp_replace(col("Preço_Unitário"), u"\u00A0", ""), "R\\$", ""))
preco_filtered = regexp_replace(preco_temp, r"[^0-9,.]", "")

preco_norm = when(
    preco_filtered.contains(","),
    regexp_replace(regexp_replace(preco_filtered, "\\.", ""), ",", ".")
).otherwise(
    regexp_replace(preco_filtered, "\\.", "")
)

qtd_raw = trim(col("Qtd_Itens_Comprados"))

qtd_norm = regexp_replace(qtd_raw, r"[^0-9]", "")

dados_2021_fix = dados_2021.withColumn("Preço_Unitário_numeric", preco_norm.cast("double")) \
                           .withColumn("Qtd_Itens_Comprados_numeric", qtd_norm.cast("double"))

#Total de itens comprados
from pyspark.sql.functions import sum as spark_sum

total_items_purchased = dados_2021_fix.agg(spark_sum("Qtd_Itens_Comprados").alias("Total_Itens_Comprados"))
total_items_purchased.show()

#Total de itens e valor por região
from pyspark.sql.functions import sum as spark_sum

total_operacoes_regiao = dados_2021_fix.groupBy("Região").agg(spark_sum("Qtd_Itens_Comprados_numeric").alias("Total_Itens_Comprados")).orderBy('Total_Itens_Comprados', ascending=False)
total_operacoes_regiao.show()

#Total de medicamentos genéricos por região

genericos_por_regiao = (

  dados_2021_fix

    .groupBy("Região")

    .agg(F.sum((F.col("Genérico") == "Sim").cast("int")).alias("qtd_genericos"))

    .orderBy("Região")

).orderBy('qtd_genericos', ascending=False)

genericos_por_regiao.show()

spark = SparkSession.builder.getOrCreate()

#Comparação entre medicamentos genéricos, originais e não informados por região
from pyspark.sql import functions as F

tipo_medicamento_por_regiao = (
  dados_2021_fix
    .groupBy("Região")
    .agg(
        F.sum(F.when(F.col("Genérico") == "Sim", 1).otherwise(0)).alias("qtd_genericos"),
        F.sum(F.when(F.col("Genérico") == "Não", 1).otherwise(0)).alias("qtd_nao_genericos"),
        F.sum(F.when(F.col("Genérico") == "Não consta", 1).otherwise(0)).alias("qtd_nao_consta")
    )
    .orderBy("qtd_genericos", ascending=False)
)

tipo_medicamento_por_regiao.show()

dados_2021_fix.write.mode('overwrite').csv('dados_2021_EDA.csv')

spark = SparkSession.builder.getOrCreate()

#Colocar os arquivos do diretório em um dataframe
repartitioned_df = spark.read.csv("dados_2021_EDA.csv", header=True, schema=dados_2021.schema)
# Fazer coalesce para uma única partição e salvar como CSV único
repartitioned_df.coalesce(1).write.mode('overwrite').csv('dados_2021_EDA_single.csv', header=True)

spark.stop()

"""# Insights
•	Em 2021, foram efetuadas 70.893 operações de compra de medicamentos e dispositivos médicos, somando 1.160.537 itens no total;

•	Analisando esta base de dados, foi possível concluir que em 2021, o estado que mais efetuou operações foi o Paraná, ao passo que Roraima foi o estado com menos operações;

•	Ao avaliar por região, percebe-se que a maior parte das operações foi realizada no sul, seguido pelo sudeste, nordeste, norte e centro-oeste;

•	No que diz respeito à preferência ou não por medicamentos genéricos, verificou-se que esse tipo de medicamento foi mais consumido na região sul, com 6.607 operações. Contudo, os medicamentos predominantes nessa região são os não genéricos, com 19.310 operações;

•	A região que comprou menos medicamentos genéricos foi o centro-oeste, com 480 operações de compra de genéricos e 1.598 operações de compra de não genéricos.

Conclui-se que uma possível ação para otimizar os investimentos futuros na saúde é a criação de campanhas em prol da compra de medicamentos genéricos, pois esta reduziria o valor total investido e ao mesmo tempo aumentaria a cobertura de medicamentos pelo SUS.
"""