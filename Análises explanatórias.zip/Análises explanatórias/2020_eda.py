# -*- coding: utf-8 -*-
"""2020 - EDA
Para esta análise, será utilizada a base de dados estruturados "Banco de Preço em Saúde - 2020", em formato .csv disponível em https://opendatasus.saude.gov.br/dataset/bps/resource/96cf6e5f-bab8-4c5a-a6ae-5f24eb07b7c2.
"""

!java -version
!pip install --upgrade pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder \
  .appName("TesteSpark") \
  .getOrCreate()
print("Spark iniciado com sucesso!")

import pandas as pd
import numpy as np
import pyspark
from pyspark.sql import SparkSession

dados_2020 = spark.read.csv("/content/2020.csv", header=True, inferSchema=True)

#Formatação
dados_2020 = spark.read.option("header", True) \
             .option("sep", ";") \
             .option("encoding", "ISO-8859-1") \
             .option("quote", '"') \
             .option("escape", '"') \
             .csv("/content/2020.csv")

dados_2020.show(5, truncate=False)
dados_2020.printSchema()

#Criar as colunas "Capacidade", "Unidade_Medida" e "Unidade_Fornecimento_Capacidade"
spark = SparkSession.builder.getOrCreate()
from pyspark.sql import functions as F

dados_2020 = dados_2020.withColumn(
  "Capacidade", F.lit(None).cast("string")
).withColumn(
  "Unidade_Medida", F.lit(None).cast("string")
).withColumn(
  "Unidade_Fornecimento_Capacidade", F.lit(None).cast("string")
)
dados_2020.show(5, truncate=False)

#preencher células em branco
from pyspark.sql.functions import col, trim, when
dados_2020 = dados_2020.withColumn(
         "Anvisa",
          when(trim(col("Anvisa")) == "", None).otherwise(col("Anvisa"))
).withColumn("Anvisa", col("Anvisa").cast("string")) \
.fillna({"Anvisa": "Não consta"})

dados_2020 = dados_2020.withColumn(
         "Genérico",
          when(trim(col("Genérico")) == "", None).otherwise(col("Genérico"))
).withColumn("Genérico", col("Genérico").cast("string")) \
.fillna({"Genérico": "Não consta"})

dados_2020 = dados_2020.withColumn(
    "Capacidade",
    when(trim(col("Capacidade")) == "", None).otherwise(col("Capacidade"))
).fillna({"Capacidade": "Não consta"}) # Removed redundant .cast("string")
dados_2020.show(108, truncate=False)

dados_2020 = dados_2020.withColumn(
    "Unidade_Medida",
    when(trim(col("Unidade_Medida")) == "", None).otherwise(col("Unidade_Medida"))
).fillna({"Unidade_Medida": "Não consta"})

dados_2020 = dados_2020.withColumn(
    "Unidade_Fornecimento_Capacidade",
    when(trim(col("Unidade_Fornecimento_Capacidade")) == "", None).otherwise(col("Unidade_Fornecimento_Capacidade"))
).fillna({"Unidade_Fornecimento_Capacidade": "Não consta"})
dados_2020.show(108, truncate=False)

spark = SparkSession.builder.getOrCreate()
#Substituir "CNPJ Fabricante" por "Fabricante"
dados_2020 = (dados_2020

   .withColumnRenamed("Fabricante", "__tmp__") \

   .withColumnRenamed("CNPJ_Fabricante", "Fabricante") \

   .withColumnRenamed("__tmp__", "CNPJ_Fabricante"))
dados_2020.show(5, truncate=False)

#Substituir "CNPJ_Fornecedor" por "Fornecedor"
dados_2020 = (dados_2020

   .withColumnRenamed("Fornecedor", "__tmp__") \

   .withColumnRenamed("CNPJ_Fornecedor", "Fornecedor") \

   .withColumnRenamed("__tmp__", "CNPJ_Fornecedor"))
dados_2020.show(5, truncate=False)

#Substituir "CNPJ_Instituição" por "Instituição"
dados_2020 = (dados_2020

   .withColumnRenamed("Nome_Instituição", "__tmp__") \

   .withColumnRenamed("CNPJ_Instituição", "Nome_Instituição") \

   .withColumnRenamed("__tmp__", "CNPJ_Instituição"))
dados_2020.show(5, truncate=False)

#Anonimizar CNPJ Fornecedor
from pyspark.sql.functions import regexp_replace
dados_2020 = dados_2020.withColumn(
          "CNPJ_Fornecedor",
          regexp_replace(col("CNPJ_Fornecedor"), r".*", "—")
)
dados_2020.show(5, truncate=False)

#Anonimizar CNPJ Fabricante
dados_2020 = dados_2020.withColumn(
          "CNPJ_Fabricante",
          regexp_replace(col("CNPJ_Fabricante"), r".*", "—")
)
dados_2020.show(5, truncate=False)

#Anonimizar CNPJ Instituição
dados_2020 = dados_2020.withColumn(
          "CNPJ_Instituição",
          regexp_replace(col("CNPJ_Instituição"), r".*", "—")
)
dados_2020.show(5, truncate=False)

#Total de operações
Total_operacoes = dados_2020.count()
print(f"Total de operações: {Total_operacoes}")

#Total de operações por estado
dados_2020.groupBy('UF').count().orderBy('count', ascending=False).show()

#Total de operações por fornecedor
dados_2020.groupBy('Fornecedor').count().orderBy('count', ascending=False).show()

#Total de operações por instituição
dados_2020.groupBy('Nome_Instituição').count().orderBy('count', ascending=False).show()

#Organizar os estados por região
from pyspark.sql import functions as F

dados_2020 = dados_2020.withColumn(
  "Região",
  F.when(F.col("UF").isin("SP", "RJ", "MG", "ES"), F.lit("Região sudeste"))
  .when(F.col("UF").isin("RS", "SC", "PR"), F.lit("Região sul"))
  .when(F.col("UF").isin("AC", "AP", "AM", "PA", "RO", "RR", "TO"), F.lit("Região norte"))
  .when(F.col("UF").isin("DF", "GO", "MT", "MS"), F.lit("Região centro-oeste"))
  .otherwise(F.lit("Região nordeste"))
)
dados_2020.show(5, truncate=False)

#Total de operações por região
dados_2020.groupBy('Região').count().orderBy('count', ascending=False).show()

#Cast regexp no preço e Qtd_Itens_Comprados
from pyspark.sql.functions import trim, when, regexp_replace, col, lit

preco_temp = trim(regexp_replace(regexp_replace(col("Preço_Unitário"), u"\u00A0", ""), "R\\$", ""))
preco_filtered = regexp_replace(preco_temp, r"[^0-9,.]", "")

preco_norm = when(
    preco_filtered.contains(","),
    regexp_replace(regexp_replace(preco_filtered, "\\.", ""), ",", ".")
).otherwise(
    regexp_replace(preco_filtered, "\\.", "")
)

qtd_raw = trim(col("Qtd_Itens_Comprados"))

qtd_norm = regexp_replace(qtd_raw, r"[^0-9]", "")

dados_2020_fix = dados_2020.withColumn("Preço_Unitário_numeric", preco_norm.cast("double")) \
                           .withColumn("Qtd_Itens_Comprados_numeric", qtd_norm.cast("double"))

#Total de itens comprados
from pyspark.sql.functions import sum as spark_sum

total_items_purchased = dados_2020_fix.agg(spark_sum("Qtd_Itens_Comprados_numeric").alias("Total_Itens_Comprados"))
total_items_purchased.show()

#Total de itens comprados por região
from pyspark.sql.functions import sum as spark_sum

total_operacoes_regiao = dados_2020_fix.groupBy("Região").agg(spark_sum("Qtd_Itens_Comprados_numeric").alias("Total_Itens_Comprados")).orderBy('Total_Itens_Comprados', ascending=False)
total_operacoes_regiao.show()

#Total de itens e valor por região
from pyspark.sql.functions import sum as spark_sum

Total_de_itens_e_valor_por_regiao = dados_2020_fix.groupBy("Região").agg(
    spark_sum("Qtd_Itens_Comprados_numeric").alias("Total_Itens_Comprados"),
    spark_sum("Preço_Unitário_numeric").alias("Valor_Total_Gasto")
).orderBy('Total_Itens_Comprados', ascending=False).show()

#Total de medicamentos genéricos por região

genericos_por_regiao = (

  dados_2020_fix

    .groupBy("Região")

    .agg(F.sum((F.col("Genérico") == "Sim").cast("int")).alias("Qtd_Genéricos"))

    .orderBy("Região")

).orderBy('Qtd_Genéricos', ascending=False)

genericos_por_regiao.show()

spark = SparkSession.builder.getOrCreate()

#Comparação entre medicamentos genéricos, originais e não informados por região
from pyspark.sql import functions as F

tipo_medicamento_por_regiao = (
  dados_2020_fix
    .groupBy("Região")
    .agg(
        F.sum(F.when(F.col("Genérico") == "Sim", 1).otherwise(0)).alias("Qtd_Genéricos"),
        F.sum(F.when(F.col("Genérico") == "Não", 1).otherwise(0)).alias("Qtd_não_Genéricos"),
        F.sum(F.when(F.col("Genérico") == "Não consta", 1).otherwise(0)).alias("Qtd_não_consta")
    )
    .orderBy("Qtd_Genéricos", ascending=False)
)

tipo_medicamento_por_regiao.show()

dados_2020.write.mode('overwrite').csv('dados_2020_EDA.csv')

spark = SparkSession.builder.getOrCreate()

#Colocar os arquivos do diretório em um dataframe
repartitioned_df = spark.read.csv("dados_2020_EDA.csv", header=True, schema=dados_2020.schema)
# Fazer coalesce para uma única partição e salvar como CSV único
repartitioned_df.coalesce(1).write.mode('overwrite').csv('dados_2020_EDA_single.csv', header=True)

spark.stop()

"""# Insights
•	Em 2020, foram efetuadas 71227 operações de compra de medicamentos e dispositivos médicos, somando 9.416.706 itens no total;

•	Analisando esta base de dados, foi possível concluir que em 2020, o estado que mais efetuou operações foi o Paraná, ao passo que o Ceará foi o estado com menos operações;

•	Ao avaliar por região, percebe-se que a maior parte das operações foi realizada no sul, seguido pelo sudeste, nordeste, norte e centro-oeste;

•	No que diz respeito à preferência ou não por medicamentos genéricos, verificou-se que esse tipo de medicamento foi mais consumido na região sul, com 6.430 operações. Contudo, os medicamentos predominantes nessa região são os não genéricos, com 19.515 operações;

•	A região que comprou menos medicamentos genéricos foi o centro-oeste, com 507 operações de compra de genéricos e 1.197 operações de compra de não genéricos.

Conclui-se que uma possível ação para otimizar os investimentos futuros na saúde é a criação de campanhas em prol da compra de medicamentos genéricos, pois esta reduziria o valor total investido e ao mesmo tempo aumentaria a cobertura de medicamentos pelo SUS.
"""