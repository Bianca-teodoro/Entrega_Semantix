# -*- coding: utf-8 -*-
"""2023- EDA
Para esta análise, será utilizada a base de dados estruturados "Banco de Preço em Saúde - 2023", em formato .csv disponível em https://opendatasus.saude.gov.br/dataset/bps/resource/cb9c9b51-4569-428b-8d64-7641d01583bf.
"""

!java -version
!pip install --upgrade pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder \
  .appName("TesteSpark") \
  .getOrCreate()
print("Spark iniciado com sucesso!")

import pandas as pd
import numpy as np
import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

dados_2023 = spark.read.csv("/content/2023.csv", header=True, inferSchema=True)

#Formatação
dados_2023 = spark.read.option("header", True) \
             .option("sep", ";") \
             .option("encoding", "ISO-8859-1") \
             .option("quote", '"') \
             .option("escape", '"') \
             .csv("/content/2023.csv")

dados_2023.show(5, truncate=False)
dados_2023.printSchema()

#preencher células em branco
from pyspark.sql.functions import col, trim, when
dados_2023 = dados_2023.withColumn(
         "Anvisa",
          when(trim(col("Anvisa")) == "", None).otherwise(col("Anvisa"))
).withColumn("Anvisa", col("Anvisa").cast("string")) \
.fillna({"Anvisa": "Não consta"})
dados_2023 = dados_2023.withColumn(
         "Genérico",
          when(trim(col("Genérico")) == "", None).otherwise(col("Genérico"))
).withColumn("Genérico", col("Genérico").cast("string")) \
.fillna({"Genérico": "Não consta"})
dados_2023 = dados_2023.withColumn(
   "Capacidade",
          when(trim(col("Capacidade")) == "", None).otherwise(col("Capacidade"))
).withColumn("Capacidade", col("Capacidade").cast("string")) \
.fillna({"Capacidade": "Não consta"})
dados_2023 = dados_2023.withColumn(
         "Unidade_Medida",
          when(trim(col("Unidade_Medida")) == "", None).otherwise(col("Unidade_Medida"))
).withColumn("Unidade_Medida", col("Unidade_Medida").cast("string")) \
.fillna({"Unidade_Medida": "Não consta"})
dados_2023.show(5, truncate=False)

#Anonimizar CNPJ Fornecedor
from pyspark.sql.functions import col, regexp_replace
dados_2023 = dados_2023.withColumn(
          "CNPJ_Fornecedor",
          regexp_replace(col("CNPJ_Fornecedor"), r".*", "—")
)
dados_2023.show(5, truncate=False)

#Anonimizar CNPJ Fabricante
dados_2023 = dados_2023.withColumn(
          "CNPJ_Fabricante",
          regexp_replace(col("CNPJ_Fabricante"), r".*", "—")
)
dados_2023.show(5, truncate=False)

#Anonimizar CNPJ Instituição
dados_2023 = dados_2023.withColumn(
          "CNPJ_Instituição",
          regexp_replace(col("CNPJ_Instituição"), r".*", "—")
)
dados_2023.show(5, truncate=False)

#Total de operações
Total_operacoes = dados_2023.count()
print(f"Total de operações: {Total_operacoes}")

#Total de operações por estado
dados_2023.groupBy('UF').count().orderBy('count', ascending=False).show()

#Total de operações por fornecedor
dados_2023.groupBy('Fornecedor').count().orderBy('count', ascending=False).show()

#Total de operações por instituição
dados_2023.groupBy('Nome_Instituição').count().orderBy('count', ascending=False).show()

#Organizar os estados por região
from pyspark.sql import functions as F

dados_2023 = dados_2023.withColumn(
  "Região",
  F.when(F.col("UF").isin("SP", "RJ", "MG", "ES"), F.lit("Região sudeste"))
  .when(F.col("UF").isin("RS", "SC", "PR"), F.lit("Região sul"))
  .when(F.col("UF").isin("AC", "AP", "AM", "PA", "RO", "RR", "TO"), F.lit("Região norte"))
  .when(F.col("UF").isin("DF", "GO", "MT", "MS"), F.lit("Região centro-oeste"))
  .otherwise(F.lit("Região nordeste"))
)
dados_2023.show(5, truncate=False)

#Total de operações por região
dados_2023.groupBy('Região').count().orderBy('count', ascending=False).show()

#Cast regexp no preço e Qtd_Itens_Comprados
from pyspark.sql.functions import trim, when, regexp_replace, col, lit

preco_temp = trim(regexp_replace(regexp_replace(col("Preço_Unitário"), u"\u00A0", ""), "R\\$", ""))
preco_filtered = regexp_replace(preco_temp, r"[^0-9,.]", "")

preco_norm = when(
    preco_filtered.contains(","),
    regexp_replace(regexp_replace(preco_filtered, "\\.", ""), ",", ".")
).otherwise(
    regexp_replace(preco_filtered, "\\.", "")
)

qtd_raw = trim(col("Qtd_Itens_Comprados"))

qtd_norm = regexp_replace(qtd_raw, r"[^0-9]", "")

dados_2023_fix = dados_2023.withColumn("Preço_Unitário_numeric", preco_norm.cast("double")) \
                           .withColumn("Qtd_Itens_Comprados_numeric", qtd_norm.cast("double"))

#Total de itens comprados
from pyspark.sql.functions import sum as spark_sum

total_items_purchased = dados_2023_fix.agg(spark_sum("Qtd_Itens_Comprados").alias("Total_Itens_Comprados"))
total_items_purchased.show()

#Total de itens e valor por região
from pyspark.sql.functions import sum as spark_sum

total_operacoes_regiao = dados_2023_fix.groupBy("Região").agg(spark_sum("Qtd_Itens_Comprados_numeric").alias("Total_Itens_Comprados")).orderBy('Total_Itens_Comprados', ascending=False)
total_operacoes_regiao.show()

spark = SparkSession.builder.getOrCreate()

#Total de medicamentos genéricos por região

Genéricos_por_regiao = (
  dados_2023_fix
    .groupBy("Região")
    .agg(F.sum(F.when(F.trim(F.col("Genérico")) == "S", 1).otherwise(0)).alias("qtd_Genéricos"))
    .orderBy("Região")
).orderBy('qtd_Genéricos', ascending=False)

Genéricos_por_regiao.show()

spark = SparkSession.builder.getOrCreate()

#Comparação entre medicamentos genéricos, originais e não informados por região
from pyspark.sql import functions as F

tipo_medicamento_por_regiao = (
  dados_2023_fix
    .groupBy("Região")
    .agg(
        F.sum(F.when(F.trim(F.col("Genérico")) == "S", 1).otherwise(0)).alias("qtd_Genéricos"),
        F.sum(F.when(F.trim(F.col("Genérico")) == "N", 1).otherwise(0)).alias("qtd_nao_Genéricos"),
        F.sum(F.when(F.trim(F.col("Genérico")) == "Não consta", 1).otherwise(0)).alias("qtd_nao_consta")
    )
    .orderBy("qtd_Genéricos", ascending=False)
)

tipo_medicamento_por_regiao.show()

dados_2023_fix.write.mode('overwrite').csv('dados_2023_EDA.csv')

spark = SparkSession.builder.getOrCreate()

#Colocar os arquivos do diretório em um dataframe
repartitioned_df = spark.read.csv("dados_2023_EDA.csv", header=True, schema=dados_2023.schema)
# Fazer coalesce para uma única partição e salvar como CSV único
repartitioned_df.coalesce(1).write.mode('overwrite').csv('dados_2023_EDA_single.csv', header=True)

spark.stop()

"""# Insights
•	Em 2023, foram efetuadas 29.428 operações de compra de medicamentos e dispositivos médicos, somando 1.023.934 itens no total;

•	Analisando esta base de dados, foi possível concluir que em 2023, o estado que mais efetuou operações foi o Paraná, ao passo que Goiânia foi o estado com menos operações;

•	Ao avaliar por região, percebe-se que a maior parte das operações foi realizada no nordeste, seguido pelo sul, sudeste, norte e centro-oeste;

•	No que diz respeito à preferência ou não por medicamentos genéricos, verificou-se que esse tipo de medicamento foi mais consumido na região nordeste, com 2.673 operações, predominando sobre os não genéricos (1.666 operações);

•	A região que comprou menos medicamentos genéricos foi o centro-oeste, com 102 operações de compra de genéricos e 167 operações de compra de não genéricos.

Conclui-se que uma possível ação para otimizar os investimentos futuros na saúde é a criação de campanhas em prol da compra de medicamentos genéricos, pois esta reduziria o valor total investido e ao mesmo tempo aumentaria a cobertura de medicamentos pelo SUS.

"""